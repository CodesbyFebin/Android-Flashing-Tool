import {
  Connection,
  PublicKey,
  LAMPORTS_PER_SOL,
  GetProgramAccountsFilter,
} from '@solana/web3.js';
import { TOKEN_PROGRAM_ID, getAccount, getMint } from '@solana/spl-token';

const RPC_ENDPOINT = 'https://api.mainnet-beta.solana.com';
export const connection = new Connection(RPC_ENDPOINT, 'confirmed');

// SKR official mint
const SKR_MINT = new PublicKey('SKRm6zv8kPAJMVMb9ci8Ps3v2ZD9U9MJ3TkLtvdsZX5');

export interface SKRBalance {
  liquid: number; // Tokens you can move/send right now
  staked: number; // Tokens currently delegated
  coolingDown: number; // Tokens unstaking (in 48h cooldown)
  total: number;
}

export interface BalanceInfo {
  sol: number;
  skr: SKRBalance;
}

/**
 * Get SOL balance for a wallet
 */
export const getSOLBalance = async (publicKey: PublicKey): Promise<number> => {
  try {
    const balance = await connection.getBalance(publicKey);
    return balance / LAMPORTS_PER_SOL;
  } catch (error) {
    console.error('Error fetching SOL balance:', error);
    throw error;
  }
};

/**
 * Get SKR balance broken down by state
 * Liquid: in token account
 * Staked: in stake account delegated to validator
 * CoolingDown: in deactivating stake account
 */
export const getSKRBalance = async (publicKey: PublicKey): Promise<SKRBalance> => {
  try {
    // Get all token accounts for SKR
    const tokenAccounts = await connection.getProgramAccounts(TOKEN_PROGRAM_ID, {
      filters: [
        {
          dataSize: 165, // Token account size
        },
        {
          memcmp: {
            offset: 0, // Mint address offset in token account
            bytes: SKR_MINT.toBase58(),
          },
        },
      ],
    });

    let liquid = 0;
    for (const account of tokenAccounts) {
      if (account.account.owner.equals(publicKey)) {
        try {
          const parsed = await getAccount(connection, account.pubkey);
          if (parsed.owner.equals(publicKey)) {
            liquid += Number(parsed.amount) / 1e9; // Assuming 9 decimals
          }
        } catch (err) {
          // Skip accounts that fail to parse
        }
      }
    }

    // Get stake accounts (simplified - in production would query stake program)
    const staked = 0; // TODO: Query stake accounts
    const coolingDown = 0; // TODO: Query deactivating stakes

    return {
      liquid,
      staked,
      coolingDown,
      total: liquid + staked + coolingDown,
    };
  } catch (error) {
    console.error('Error fetching SKR balance:', error);
    // Return zero balances on error
    return { liquid: 0, staked: 0, coolingDown: 0, total: 0 };
  }
};

/**
 * Get complete balance info (SOL + SKR)
 */
export const getBalances = async (publicKey: PublicKey): Promise<BalanceInfo> => {
  const [sol, skr] = await Promise.all([getSOLBalance(publicKey), getSKRBalance(publicKey)]);
  return { sol, skr };
};

/**
 * Get all token mints in a wallet (for fake token detection)
 */
export const getWalletMints = async (publicKey: PublicKey): Promise<string[]> => {
  try {
    const tokenAccounts = await connection.getProgramAccounts(TOKEN_PROGRAM_ID, {
      filters: [
        {
          dataSize: 165,
        },
        {
          memcmp: {
            offset: 32, // Owner offset
            bytes: publicKey.toBase58(),
          },
        },
      ],
    });

    const mints: string[] = [];
    for (const account of tokenAccounts) {
      try {
        const parsed = await getAccount(connection, account.pubkey);
        mints.push(parsed.mint.toBase58());
      } catch (err) {
        // Skip
      }
    }
    return mints;
  } catch (error) {
    console.error('Error fetching wallet mints:', error);
    return [];
  }
};

/**
 * Format lamports to SOL
 */
export const lamportsToSOL = (lamports: number): number => {
  return lamports / LAMPORTS_PER_SOL;
};

/**
 * Format base units to token (assuming 9 decimals for most Solana tokens)
 */
export const baseUnitsToToken = (amount: number, decimals: number = 9): number => {
  return amount / Math.pow(10, decimals);
};

/**
 * Check if a mint is the official SKR
 */
export const isOfficialSKR = (mint: string): boolean => {
  return mint === SKR_MINT.toBase58();
};

/**
 * Get address string (first 20 chars + ...)
 */
export const truncateAddress = (address: string, chars: number = 20): string => {
  if (address.length <= chars) return address;
  return address.slice(0, chars) + '...';
};
