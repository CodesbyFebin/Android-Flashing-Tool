import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { DecodedInstruction } from '../decoders/stakeDecoder';

const DARK_BG = '#0a0a0a';
const DARK_CARD = '#1a1a1a';
const GREEN = '#00ff88';
const RED = '#ef4444';
const YELLOW = '#fbbf24';
const GRAY = '#888';

interface ClearanceCardProps {
  instruction: DecodedInstruction;
  onApprove: () => void;
  onReject: () => void;
  dAppName?: string;
  loading?: boolean;
}

export const ClearanceCard: React.FC<ClearanceCardProps> = ({
  instruction,
  onApprove,
  onReject,
  dAppName = 'App',
  loading = false,
}) => {
  const getActionColor = (action: string): string => {
    if (action.includes('UNSTAKE') || action.includes('WITHDRAW')) return RED;
    if (action === 'UNKNOWN') return YELLOW;
    return GREEN;
  };

  const getActionEmoji = (action: string): string => {
    switch (action) {
      case 'DELEGATE':
      case 'STAKE':
        return '📌';
      case 'UNSTAKE':
        return '📍';
      case 'WITHDRAW':
        return '🪙';
      case 'CLAIM':
        return '🎁';
      case 'TRANSFER':
        return '📤';
      case 'APPROVE':
        return '🔓';
      case 'CHANGE_AUTHORITY':
        return '🔴';
      default:
        return '⚠️';
    }
  };

  const actionColor = getActionColor(instruction.action);
  const actionEmoji = getActionEmoji(instruction.action);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>CLEARANCE</Text>
        <Text style={styles.subheader}>Before you sign</Text>
      </View>

      <ScrollView
        style={styles.cardScroll}
        showsVerticalScrollIndicator={false}
        scrollEnabled={true}
      >
        <View style={[styles.card, { borderColor: actionColor }]}>
          {/* Action Header */}
          <View style={styles.actionHeader}>
            <Text style={styles.actionEmoji}>{actionEmoji}</Text>
            <Text style={[styles.actionTitle, { color: actionColor }]}>
              {instruction.action.replace(/_/g, ' ')}
            </Text>
          </View>

          {/* Main Message */}
          <View style={styles.messageBox}>
            <Text style={styles.message}>{instruction.plainEnglish}</Text>
          </View>

          {/* Amount (if present) */}
          {instruction.amount && (
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Amount</Text>
              <Text style={styles.infoValue}>
                {instruction.amount.toLocaleString()} {instruction.token || 'tokens'}
              </Text>
            </View>
          )}

          {/* Program Info */}
          <View style={styles.programBox}>
            <Text style={styles.programLabel}>Program</Text>
            <Text style={styles.programName}>{instruction.program}</Text>
            {instruction.isFirstTime && !instruction.isOfficial && (
              <Text style={styles.warningText}>⚠️ First time you are seeing this</Text>
            )}
            {instruction.isOfficial && (
              <Text style={styles.officialText}>✓ Official Program</Text>
            )}
          </View>

          {/* Warnings */}
          {instruction.warnings.length > 0 && (
            <View style={styles.warningsBox}>
              <Text style={styles.warningsTitle}>⚠️ Important</Text>
              {instruction.warnings.map((warning, idx) => (
                <Text key={idx} style={styles.warningLine}>
                  {warning}
                </Text>
              ))}
            </View>
          )}

          {/* dApp Info */}
          {dAppName && (
            <View style={styles.dAppBox}>
              <Text style={styles.dAppLabel}>Requested by</Text>
              <Text style={styles.dAppName}>{dAppName}</Text>
            </View>
          )}

          {/* Fee Note */}
          <View style={styles.feeBox}>
            <Text style={styles.feeText}>⚡ Transaction fee will be paid in SOL</Text>
          </View>
        </View>
      </ScrollView>

      {/* Buttons */}
      <View style={styles.buttonContainer}>
        <TouchableOpacity
          style={[styles.button, styles.rejectButton]}
          onPress={onReject}
          disabled={loading}
        >
          <Text style={styles.rejectText}>← REJECT</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, styles.approveButton]}
          onPress={onApprove}
          disabled={loading}
        >
          <Text style={styles.approveText}>{loading ? 'Signing...' : 'APPROVE →'}</Text>
        </TouchableOpacity>
      </View>

      {/* Safety Footer */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>
          Clearance shows what this signature will do. Seed Vault still signs. Be careful.
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: DARK_BG,
    paddingHorizontal: 16,
    paddingTop: 20,
    paddingBottom: 20,
  },
  header: {
    marginBottom: 20,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: GREEN,
  },
  subheader: {
    fontSize: 12,
    color: GRAY,
    marginTop: 4,
  },
  cardScroll: {
    flex: 1,
    marginBottom: 16,
  },
  card: {
    backgroundColor: DARK_CARD,
    borderWidth: 2,
    borderRadius: 8,
    padding: 16,
    minHeight: 300,
  },
  actionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  actionEmoji: {
    fontSize: 28,
    marginRight: 12,
  },
  actionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    flex: 1,
  },
  messageBox: {
    backgroundColor: '#000',
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 6,
    padding: 12,
    marginBottom: 14,
  },
  message: {
    color: GREEN,
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '500',
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  infoLabel: {
    color: GREEN,
    fontSize: 11,
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  infoValue: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
    fontFamily: 'monospace',
  },
  programBox: {
    backgroundColor: '#000',
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 6,
    padding: 10,
    marginVertical: 12,
  },
  programLabel: {
    color: GREEN,
    fontSize: 10,
    fontWeight: 'bold',
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  programName: {
    color: '#00ffff',
    fontSize: 12,
    fontFamily: 'monospace',
  },
  officialText: {
    color: '#4ade80',
    fontSize: 10,
    fontWeight: '600',
    marginTop: 6,
  },
  warningText: {
    color: YELLOW,
    fontSize: 10,
    fontWeight: '600',
    marginTop: 6,
  },
  warningsBox: {
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    borderWidth: 1,
    borderColor: RED,
    borderRadius: 6,
    padding: 10,
    marginVertical: 12,
  },
  warningsTitle: {
    color: RED,
    fontSize: 12,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  warningLine: {
    color: RED,
    fontSize: 11,
    lineHeight: 16,
    marginBottom: 4,
  },
  dAppBox: {
    backgroundColor: '#000',
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 6,
    padding: 10,
    marginVertical: 10,
  },
  dAppLabel: {
    color: GREEN,
    fontSize: 10,
    fontWeight: 'bold',
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  dAppName: {
    color: '#fff',
    fontSize: 12,
  },
  feeBox: {
    backgroundColor: 'rgba(59, 130, 246, 0.1)',
    borderLeftWidth: 3,
    borderLeftColor: '#3b82f6',
    paddingLeft: 10,
    paddingVertical: 8,
    marginTop: 12,
  },
  feeText: {
    color: '#60a5fa',
    fontSize: 11,
  },
  buttonContainer: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 12,
  },
  button: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rejectButton: {
    backgroundColor: '#333',
    borderWidth: 1,
    borderColor: RED,
  },
  rejectText: {
    color: RED,
    fontWeight: 'bold',
    fontSize: 14,
  },
  approveButton: {
    backgroundColor: GREEN,
  },
  approveText: {
    color: '#000',
    fontWeight: 'bold',
    fontSize: 14,
  },
  footer: {
    paddingHorizontal: 12,
    paddingVertical: 10,
    backgroundColor: '#1a1a1a',
    borderRadius: 6,
    borderLeftWidth: 3,
    borderLeftColor: YELLOW,
  },
  footerText: {
    color: GRAY,
    fontSize: 10,
    lineHeight: 14,
  },
});
