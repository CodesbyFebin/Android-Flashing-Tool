import { PublicKey, TransactionInstruction } from '@solana/web3.js';

export interface DecodedInstruction {
  action: string; // "STAKE" | "UNSTAKE" | "CLAIM" | "WITHDRAW" | "DELEGATE" | "UNKNOWN"
  plainEnglish: string;
  warnings: string[];
  amount?: number;
  token?: string;
  recipient?: string;
  source?: string;
  program: string;
  isOfficial: boolean;
  isFirstTime: boolean;
}

// Known program IDs
const KNOWN_PROGRAMS: Record<string, { name: string; type: string }> = {
  'Stake11111111111111111111111111111111111111': {
    name: 'Stake Program (OFFICIAL)',
    type: 'solana-stake',
  },
  'TokenkegQfeZyiNwAJsyFbPVwwQQfqarXtrnZhfjrx': {
    name: 'Token Program (OFFICIAL)',
    type: 'spl-token',
  },
  'ATokenGPvbdGVqstVQmcLsNZAqeEjlCoquQBndpwgcTK': {
    name: 'Associated Token Program (OFFICIAL)',
    type: 'ata',
  },
  'MarinadeMintCgp7ZVZZkzFH84hTyKjv8wvgHMvQoqZV': {
    name: 'Marinade Staking (OFFICIAL)',
    type: 'marinade',
  },
  'LidoVault111111111111111111111111111111111': {
    name: 'Lido Staking (OFFICIAL)',
    type: 'lido',
  },
  'jitoSOL1111111111111111111111111111111111': {
    name: 'Jito Staking (OFFICIAL)',
    type: 'jito',
  },
};

// SKR official mint
const SKR_OFFICIAL_MINT = 'SKRm6zv8kPAJMVMb9ci8Ps3v2ZD9U9MJ3TkLtvdsZX5';

export const decodeInstruction = (
  instruction: TransactionInstruction,
  userAddress: string,
  previousSignatures?: string[]
): DecodedInstruction => {
  const programId = instruction.programId.toBase58();
  const knownProgram = KNOWN_PROGRAMS[programId];
  const isFirstTime = !previousSignatures?.includes(programId);

  // If we recognize the program
  if (knownProgram) {
    if (knownProgram.type === 'spl-token') {
      return decodeTokenInstruction(instruction, knownProgram, isFirstTime);
    } else if (knownProgram.type === 'solana-stake') {
      return decodeStakeInstruction(instruction, knownProgram, isFirstTime);
    } else if (knownProgram.type === 'marinade') {
      return decodeMarinade(instruction, knownProgram, isFirstTime);
    }
  }

  // Unknown program
  return {
    action: 'UNKNOWN',
    plainEnglish: `Unknown program instruction. Program ID: ${programId.slice(0, 20)}...`,
    warnings: ['⚠️ You have not signed this program before', '⚠️ Unknown program - proceed with caution'],
    program: programId,
    isOfficial: false,
    isFirstTime: true,
  };
};

const decodeTokenInstruction = (
  instruction: TransactionInstruction,
  program: { name: string; type: string },
  isFirstTime: boolean
): DecodedInstruction => {
  // Check if it's a transfer instruction (0x03)
  const data = instruction.data;
  if (data.length > 0 && data[0] === 3) {
    // Transfer instruction
    const amount = data.readBigUInt64LE(1);
    return {
      action: 'TRANSFER',
      plainEnglish: `You are sending ${(Number(amount) / 1e9).toFixed(6)} tokens to another wallet.`,
      warnings: ['⚠️ Make sure the destination is correct - transfers cannot be reversed'],
      amount: Number(amount),
      token: 'SKR',
      program: program.name,
      isOfficial: true,
      isFirstTime: false,
    };
  }

  // Approve instruction (0x04)
  if (data.length > 0 && data[0] === 4) {
    return {
      action: 'APPROVE',
      plainEnglish: 'You are approving a third-party app to use your tokens.',
      warnings: [
        '⚠️ UNLIMITED DELEGATION: This app can repeatedly pull tokens',
        '⚠️ Revoke this if you stop trusting the app',
      ],
      program: program.name,
      isOfficial: true,
      isFirstTime: false,
    };
  }

  return {
    action: 'TOKEN_ACTION',
    plainEnglish: 'Token program instruction.',
    warnings: [],
    program: program.name,
    isOfficial: true,
    isFirstTime,
  };
};

const decodeStakeInstruction = (
  instruction: TransactionInstruction,
  program: { name: string; type: string },
  isFirstTime: boolean
): DecodedInstruction => {
  const data = instruction.data;
  const instructionType = data[0];

  // Instruction type 0 = Initialize
  if (instructionType === 0) {
    return {
      action: 'STAKE_INITIALIZE',
      plainEnglish: 'You are initializing a new stake account.',
      warnings: ['This creates a new account on-chain'],
      program: program.name,
      isOfficial: true,
      isFirstTime,
    };
  }

  // Instruction type 1 = Authorize
  if (instructionType === 1) {
    return {
      action: 'CHANGE_AUTHORITY',
      plainEnglish: 'You are changing who controls this stake account.',
      warnings: [
        '🔴 CRITICAL: This changes the owner of your stake',
        'After this, only the new authority can move your SKR',
      ],
      program: program.name,
      isOfficial: true,
      isFirstTime,
    };
  }

  // Instruction type 3 = Delegate
  if (instructionType === 3) {
    return {
      action: 'DELEGATE',
      plainEnglish:
        'You are delegating your stake to a validator (or staking pool guardian).',
      warnings: [
        '✓ Your SKR becomes staked',
        '⚠️ Rewards start in the next epoch',
        '⚠️ You cannot move this SKR until you undelegate',
      ],
      program: program.name,
      isOfficial: true,
      isFirstTime,
    };
  }

  // Instruction type 5 = Deactivate
  if (instructionType === 5) {
    return {
      action: 'UNSTAKE',
      plainEnglish: 'You are unstaking your SKR. Rewards will stop immediately.',
      warnings: [
        '🔴 REWARDS STOP NOW: You earn nothing for the next 48 hours',
        '⏱️ After 48 hours, you can withdraw to your wallet',
        '💰 Any rewards earned this epoch are forfeited',
      ],
      program: program.name,
      isOfficial: true,
      isFirstTime,
    };
  }

  // Instruction type 7 = Withdraw
  if (instructionType === 7) {
    const amount = data.readBigUInt64LE(1);
    return {
      action: 'WITHDRAW',
      plainEnglish: `You are withdrawing ${(Number(amount) / 1e9).toFixed(0)} SKR to your wallet.`,
      warnings: [
        '✓ This moves SKR from cooling-down to liquid',
        '✓ You can now transfer, sell, or move this SKR',
      ],
      amount: Number(amount),
      program: program.name,
      isOfficial: true,
      isFirstTime,
    };
  }

  return {
    action: 'STAKE_ACTION',
    plainEnglish: 'Stake program instruction.',
    warnings: [],
    program: program.name,
    isOfficial: true,
    isFirstTime,
  };
};

const decodeMarinade = (
  instruction: TransactionInstruction,
  program: { name: string; type: string },
  isFirstTime: boolean
): DecodedInstruction => {
  // Simplified - in production, would parse Marinade-specific instruction data
  return {
    action: 'STAKE',
    plainEnglish: 'You are staking SOL into Marinade (liquid staking).',
    warnings: ['You receive mSOL tokens (Marinade stake tokens)'],
    program: program.name,
    isOfficial: true,
    isFirstTime,
  };
};

export const isOfficalSKRMint = (mint: string): boolean => {
  return mint === SKR_OFFICIAL_MINT;
};

export const getProgramName = (programId: string): string => {
  return KNOWN_PROGRAMS[programId]?.name || `Unknown Program`;
};

export const isFakeTokenWarning = (token: string, walletMints: string[]): boolean => {
  return walletMints.includes(token) && token !== SKR_OFFICIAL_MINT;
};
