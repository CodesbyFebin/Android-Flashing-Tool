import * as Crypto from 'expo-crypto';

export interface ReviewedAction {
  messageHash: string;
  network: string;
  account: string;
  reviewedAt: number;
}

export async function hashTransaction(txData: string): Promise<string> {
  return await Crypto.digestStringAsync(
    Crypto.CryptoDigestAlgorithm.SHA256,
    txData
  );
}

export async function prepareReview(
  txData: string,
  network: string,
  account: string
): Promise<ReviewedAction> {
  const messageHash = await hashTransaction(txData);
  return {
    messageHash,
    network,
    account,
    reviewedAt: Date.now(),
  };
}

export async function assertUnchanged(
  txData: string,
  review: ReviewedAction
): Promise<void> {
  const messageHash = await hashTransaction(txData);
  if (messageHash !== review.messageHash) {
    throw new Error('MESSAGE_CHANGED: Transaction was modified after review');
  }
}
