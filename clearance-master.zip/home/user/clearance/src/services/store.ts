import AsyncStorage from '@react-native-async-storage/async-storage';
import { Action } from '../models/Action';
import { Evidence } from '../models/Evidence';
import { Receipt } from '../models/Receipt';

const ACTIONS_KEY = 'clearance:actions';
const EVIDENCE_KEY = 'clearance:evidence';
const RECEIPTS_KEY = 'clearance:receipts';

export async function saveAction(action: Action): Promise<void> {
  const actions = await getActions();
  const filtered = actions.filter(a => a.id !== action.id);
  filtered.push(action);
  await AsyncStorage.setItem(ACTIONS_KEY, JSON.stringify(filtered));
}

export async function getActions(): Promise<Action[]> {
  const data = await AsyncStorage.getItem(ACTIONS_KEY);
  return data ? JSON.parse(data) : [];
}

export async function getAction(id: string): Promise<Action | null> {
  const actions = await getActions();
  return actions.find(a => a.id === id) || null;
}

export async function saveEvidence(evidence: Evidence): Promise<void> {
  const all = await getEvidence();
  const filtered = all.filter(e => e.actionId !== evidence.actionId);
  filtered.push(evidence);
  await AsyncStorage.setItem(EVIDENCE_KEY, JSON.stringify(filtered));
}

export async function getEvidence(): Promise<Evidence[]> {
  const data = await AsyncStorage.getItem(EVIDENCE_KEY);
  return data ? JSON.parse(data) : [];
}

export async function getEvidenceForAction(actionId: string): Promise<Evidence | null> {
  const all = await getEvidence();
  return all.find(e => e.actionId === actionId) || null;
}

export async function saveReceipt(receipt: Receipt): Promise<void> {
  const receipts = await getReceipts();
  const filtered = receipts.filter(r => r.actionId !== receipt.actionId);
  filtered.push(receipt);
  await AsyncStorage.setItem(RECEIPTS_KEY, JSON.stringify(filtered));
}

export async function getReceipts(): Promise<Receipt[]> {
  const data = await AsyncStorage.getItem(RECEIPTS_KEY);
  return data ? JSON.parse(data) : [];
}

export async function getReceipt(actionId: string): Promise<Receipt | null> {
  const receipts = await getReceipts();
  return receipts.find(r => r.actionId === actionId) || null;
}
