import { Connection } from '@solana/web3.js';
import { SettlementStatus } from '../models/Receipt';

const DEVNET_RPC = 'https://api.devnet.solana.com';
const MAINNET_RPC = 'https://api.mainnet-beta.solana.com';

export async function observeSettlement(
  signature: string,
  network: 'devnet' | 'mainnet-beta' = 'devnet'
): Promise<SettlementStatus> {
  const rpc = network === 'devnet' ? DEVNET_RPC : MAINNET_RPC;
  const conn = new Connection(rpc, 'confirmed');

  try {
    const statuses = await conn.getSignatureStatuses([signature]);
    const status = statuses.value[0];

    if (!status) {
      return 'pending';
    }

    if (status.err) {
      return 'failed';
    }

    if (status.confirmationStatus === 'confirmed') {
      return 'confirmed';
    }

    if (status.confirmationStatus === 'finalized') {
      return 'finalized';
    }

    return 'pending';
  } catch (error) {
    console.error('Settlement observation error:', error);
    return 'pending';
  }
}

export async function waitForSettlement(
  signature: string,
  network: 'devnet' | 'mainnet-beta' = 'devnet',
  maxAttempts: number = 60,
  delayMs: number = 1000
): Promise<SettlementStatus> {
  for (let i = 0; i < maxAttempts; i++) {
    const status = await observeSettlement(signature, network);

    if (status === 'confirmed' || status === 'finalized' || status === 'failed') {
      return status;
    }

    if (i < maxAttempts - 1) {
      await new Promise(resolve => setTimeout(resolve, delayMs));
    }
  }

  return 'pending';
}
