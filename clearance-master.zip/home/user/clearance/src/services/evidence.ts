import * as Crypto from 'expo-crypto';
import * as FileSystem from 'expo-file-system';
import * as ImagePicker from 'expo-image-picker';
import { Evidence, canonicalManifest } from '../models/Evidence';

export async function captureEvidence(actionId: string, note: string): Promise<Evidence> {
  const { status } = await ImagePicker.requestCameraPermissionsAsync();
  if (status !== 'granted') {
    throw new Error('Camera permission denied');
  }

  const result = await ImagePicker.launchCameraAsync({
    quality: 0.8,
    base64: false,
  });

  if (!result.assets || result.assets.length === 0) {
    throw new Error('No photo captured');
  }

  const documentsDir = FileSystem.documentDirectory || '';
  const evidenceDir = `${documentsDir}evidence/`;

  try {
    await FileSystem.makeDirectoryAsync(evidenceDir, { intermediates: true });
  } catch (e) {
    // Directory might already exist
  }

  const timestamp = Date.now();
  const photoPath = `${evidenceDir}${actionId}_${timestamp}.jpg`;

  await FileSystem.copyAsync({
    from: result.assets[0].uri,
    to: photoPath,
  });

  const photoBase64 = await FileSystem.readAsStringAsync(photoPath, {
    encoding: FileSystem.EncodingType.Base64,
  });

  const photoSha256 = await Crypto.digestStringAsync(
    Crypto.CryptoDigestAlgorithm.SHA256,
    photoBase64
  );

  const manifest = {
    actionId,
    photoSha256,
    note,
    capturedAt: timestamp,
  };

  const manifestSha256 = await Crypto.digestStringAsync(
    Crypto.CryptoDigestAlgorithm.SHA256,
    canonicalManifest({ ...manifest, photoSha256, photoPath, manifestSha256: '' })
  );

  return {
    actionId,
    photoPath,
    photoSha256,
    note,
    capturedAt: timestamp,
    manifestSha256,
  };
}

export async function hashPhotoFile(photoPath: string): Promise<string> {
  const photoBase64 = await FileSystem.readAsStringAsync(photoPath, {
    encoding: FileSystem.EncodingType.Base64,
  });

  return await Crypto.digestStringAsync(
    Crypto.CryptoDigestAlgorithm.SHA256,
    photoBase64
  );
}
