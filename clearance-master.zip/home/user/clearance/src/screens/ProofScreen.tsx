import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { Receipt, SettlementStatus } from '../models/Receipt';
import { Evidence } from '../models/Evidence';
import { getReceipts, getEvidenceForAction, getAction } from '../services/store';
import { observeSettlement } from '../services/settlement';

const DARK_BG = '#0a0a0a';
const DARK_CARD = '#1a1a1a';
const GREEN = '#00ff88';
const GRAY = '#666';
const YELLOW = '#fbbf24';

interface ReceiptWithDetails extends Receipt {
  evidence?: Evidence;
  taskId?: string;
}

export const ProofScreen: React.FC = () => {
  const [receipts, setReceipts] = useState<ReceiptWithDetails[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadReceipts();
    const interval = setInterval(updateSettlements, 5000);
    return () => clearInterval(interval);
  }, []);

  const loadReceipts = async () => {
    setLoading(true);
    try {
      const allReceipts = await getReceipts();
      const withDetails: ReceiptWithDetails[] = [];

      for (const receipt of allReceipts) {
        const evidence = await getEvidenceForAction(receipt.actionId);
        const action = await getAction(receipt.actionId);
        withDetails.push({
          ...receipt,
          evidence: evidence || undefined,
          taskId: action?.taskId,
        });
      }

      setReceipts(withDetails.sort((a, b) => b.observedAt - a.observedAt));
    } catch (error) {
      console.error('Error loading receipts:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateSettlements = async () => {
    try {
      for (const receipt of receipts) {
        const status = await observeSettlement(receipt.transactionSignature);
        if (status !== receipt.settlementStatus) {
          // Update receipt in store and local state
          const updated = { ...receipt, settlementStatus: status };
          setReceipts(prev =>
            prev.map(r => (r.actionId === receipt.actionId ? updated : r))
          );
        }
      }
    } catch (error) {
      console.error('Error updating settlements:', error);
    }
  };

  const getStatusColor = (status: SettlementStatus): string => {
    switch (status) {
      case 'confirmed':
        return '#4ade80';
      case 'finalized':
        return GREEN;
      case 'failed':
        return '#ef4444';
      default:
        return YELLOW;
    }
  };

  const getStatusEmoji = (status: SettlementStatus): string => {
    switch (status) {
      case 'confirmed':
        return '✓';
      case 'finalized':
        return '✓✓';
      case 'failed':
        return '✗';
      default:
        return '⏳';
    }
  };

  const exportReceipt = (receipt: ReceiptWithDetails) => {
    const data = {
      actionId: receipt.actionId,
      taskId: receipt.taskId,
      evidenceDigest: receipt.evidenceDigest,
      transactionSignature: receipt.transactionSignature,
      settlementStatus: receipt.settlementStatus,
      observedAt: new Date(receipt.observedAt).toISOString(),
      evidence: receipt.evidence ? {
        photoSha256: receipt.evidence.photoSha256,
        note: receipt.evidence.note,
        manifestSha256: receipt.evidence.manifestSha256,
      } : null,
    };

    Alert.alert(
      'Receipt Exported',
      JSON.stringify(data, null, 2),
      [{ text: 'OK' }]
    );
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>📜 Proof</Text>
        <ActivityIndicator color={GREEN} size="large" />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <Text style={styles.title}>📜 Proof</Text>
      <Text style={styles.subtitle}>Verified receipts with evidence digests</Text>

      {receipts.length === 0 ? (
        <View style={styles.emptyCard}>
          <Text style={styles.emptyText}>No receipts yet</Text>
        </View>
      ) : (
        receipts.map((receipt) => (
          <View key={receipt.actionId} style={styles.card}>
            {/* Header */}
            <View style={styles.cardHeader}>
              <View>
                <Text style={styles.actionId}>{receipt.taskId || receipt.actionId}</Text>
                <Text style={styles.timestamp}>
                  {new Date(receipt.observedAt).toLocaleString()}
                </Text>
              </View>
              <Text
                style={[
                  styles.statusBadge,
                  { color: getStatusColor(receipt.settlementStatus) },
                ]}
              >
                {getStatusEmoji(receipt.settlementStatus)} {receipt.settlementStatus}
              </Text>
            </View>

            {/* Signature */}
            <View style={styles.signatureBox}>
              <Text style={styles.label}>Signature</Text>
              <Text style={styles.monospace}>
                {receipt.transactionSignature.slice(0, 20)}...
              </Text>
            </View>

            {/* Evidence Digest */}
            <View style={styles.digestBox}>
              <Text style={styles.label}>Evidence Digest</Text>
              <Text style={styles.monospace}>
                {receipt.evidenceDigest.slice(0, 32)}...
              </Text>
            </View>

            {/* Evidence Details */}
            {receipt.evidence && (
              <View style={styles.evidenceBox}>
                <Text style={styles.label}>Evidence</Text>
                <Text style={styles.detailText}>
                  📷 Photo: {receipt.evidence.photoSha256.slice(0, 16)}...
                </Text>
                <Text style={styles.detailText}>
                  📝 Note: {receipt.evidence.note}
                </Text>
              </View>
            )}

            {/* Export Button */}
            <TouchableOpacity
              style={styles.exportButton}
              onPress={() => exportReceipt(receipt)}
            >
              <Text style={styles.exportButtonText}>📤 Export Receipt</Text>
            </TouchableOpacity>
          </View>
        ))
      )}

      {/* Info Box */}
      <View style={styles.infoBox}>
        <Text style={styles.infoTitle}>💡 About Receipts</Text>
        <Text style={styles.infoText}>
          Each receipt includes a transaction signature, evidence digest, and settlement status.
        </Text>
        <Text style={styles.infoText}>
          The evidence digest is a SHA-256 hash of your photo, note, and timestamp.
        </Text>
        <Text style={styles.infoText}>
          Use receipts to prove what you approved and when it settled on-chain.
        </Text>
      </View>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: DARK_BG,
    padding: 16,
    paddingTop: 40,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: GREEN,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 12,
    color: GRAY,
    marginBottom: 20,
  },
  emptyCard: {
    backgroundColor: DARK_CARD,
    borderWidth: 1,
    borderColor: GREEN,
    borderRadius: 8,
    padding: 30,
    alignItems: 'center',
    marginBottom: 16,
  },
  emptyText: {
    color: GRAY,
    fontSize: 14,
  },
  card: {
    backgroundColor: DARK_CARD,
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 8,
    padding: 14,
    marginBottom: 12,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  actionId: {
    color: GREEN,
    fontSize: 12,
    fontWeight: 'bold',
  },
  timestamp: {
    color: GRAY,
    fontSize: 10,
    marginTop: 2,
  },
  statusBadge: {
    fontSize: 10,
    fontWeight: 'bold',
    borderWidth: 1,
    borderColor: 'currentColor',
    borderRadius: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  label: {
    color: GREEN,
    fontSize: 9,
    fontWeight: 'bold',
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  signatureBox: {
    backgroundColor: '#000',
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 4,
    padding: 8,
    marginBottom: 10,
  },
  digestBox: {
    backgroundColor: '#000',
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 4,
    padding: 8,
    marginBottom: 10,
  },
  evidenceBox: {
    backgroundColor: 'rgba(251, 191, 36, 0.05)',
    borderWidth: 1,
    borderColor: YELLOW,
    borderRadius: 4,
    padding: 10,
    marginBottom: 10,
  },
  detailText: {
    color: '#fff',
    fontSize: 10,
    lineHeight: 14,
    marginBottom: 4,
  },
  monospace: {
    color: '#00ffff',
    fontSize: 9,
    fontFamily: 'monospace',
  },
  exportButton: {
    backgroundColor: GREEN,
    borderRadius: 4,
    paddingVertical: 8,
    alignItems: 'center',
  },
  exportButtonText: {
    color: '#000',
    fontSize: 11,
    fontWeight: 'bold',
  },
  infoBox: {
    backgroundColor: DARK_CARD,
    borderWidth: 1,
    borderColor: '#444',
    borderRadius: 8,
    padding: 12,
    marginTop: 20,
  },
  infoTitle: {
    color: GREEN,
    fontSize: 11,
    fontWeight: 'bold',
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  infoText: {
    color: GRAY,
    fontSize: 10,
    lineHeight: 14,
    marginBottom: 6,
  },
});
