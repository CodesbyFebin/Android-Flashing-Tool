import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';

const DARK_BG = '#0a0a0a';
const DARK_CARD = '#1a1a1a';
const GREEN = '#00ff88';
const GRAY = '#666';

interface SignatureRecord {
  id: string;
  timestamp: Date;
  action: string;
  amount?: number;
  token?: string;
  status: 'completed' | 'cooling-down' | 'pending';
  plainEnglish: string;
  signature: string;
}

interface HistoryScreenProps {
  wallet: string | null;
}

export const HistoryScreen: React.FC<HistoryScreenProps> = ({ wallet }) => {
  // Mock history data - in production, this would be loaded from device storage or blockchain
  const mockHistory: SignatureRecord[] = [
    {
      id: '1',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      action: 'DELEGATE',
      amount: 1000,
      token: 'SKR',
      status: 'completed',
      plainEnglish: 'Delegated 1,000 SKR to Marinade validator. Rewards start next epoch.',
      signature: '4ade80...aef89d',
    },
    {
      id: '2',
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
      action: 'UNSTAKE',
      amount: 500,
      token: 'SKR',
      status: 'cooling-down',
      plainEnglish:
        'Unstaked 500 SKR. Rewards stopped. Withdraw available in 48 hours (tomorrow at 14:32).',
      signature: '3f89ae...2bcde1',
    },
    {
      id: '3',
      timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
      action: 'CLAIM',
      amount: 50,
      token: 'SKR',
      status: 'completed',
      plainEnglish: 'Claimed 50 SKR in rewards from validator.',
      signature: '2f78bc...9acde2',
    },
  ];

  const getStatusColor = (status: string): string => {
    switch (status) {
      case 'completed':
        return '#4ade80';
      case 'cooling-down':
        return '#fbbf24';
      case 'pending':
        return '#60a5fa';
      default:
        return GRAY;
    }
  };

  const getStatusEmoji = (status: string): string => {
    switch (status) {
      case 'completed':
        return '✓';
      case 'cooling-down':
        return '⏱️';
      case 'pending':
        return '⏳';
      default:
        return '?';
    }
  };

  const getActionEmoji = (action: string): string => {
    switch (action) {
      case 'DELEGATE':
        return '📌';
      case 'UNSTAKE':
        return '📍';
      case 'CLAIM':
        return '🎁';
      case 'WITHDRAW':
        return '🪙';
      default:
        return '⚠️';
    }
  };

  const formatTime = (date: Date): string => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  if (!wallet) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>📜 History</Text>
        <Text style={styles.subtitle}>Your approved transactions</Text>
        <View style={styles.emptyCard}>
          <Text style={styles.emptyText}>Connect your wallet to see history</Text>
        </View>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <Text style={styles.title}>📜 History</Text>
      <Text style={styles.subtitle}>Your approved transactions (what Clearance showed you)</Text>

      {mockHistory.length === 0 ? (
        <View style={styles.emptyCard}>
          <Text style={styles.emptyText}>No transactions yet</Text>
        </View>
      ) : (
        mockHistory.map((record) => (
          <View key={record.id} style={styles.card}>
            {/* Header */}
            <View style={styles.cardHeader}>
              <View style={styles.titleRow}>
                <Text style={styles.emoji}>{getActionEmoji(record.action)}</Text>
                <View style={styles.titleCol}>
                  <Text style={styles.actionTitle}>{record.action.replace(/_/g, ' ')}</Text>
                  <Text style={styles.timestamp}>{formatTime(record.timestamp)}</Text>
                </View>
              </View>
              <Text
                style={[
                  styles.statusBadge,
                  { color: getStatusColor(record.status), borderColor: getStatusColor(record.status) },
                ]}
              >
                {getStatusEmoji(record.status)} {record.status.replace('-', ' ')}
              </Text>
            </View>

            {/* Amount */}
            {record.amount && (
              <View style={styles.amountRow}>
                <Text style={styles.amountLabel}>Amount</Text>
                <Text style={styles.amount}>
                  {record.amount.toLocaleString()} {record.token}
                </Text>
              </View>
            )}

            {/* Plain English */}
            <View style={styles.plainEnglishBox}>
              <Text style={styles.plainEnglish}>{record.plainEnglish}</Text>
            </View>

            {/* Signature */}
            <View style={styles.signatureBox}>
              <Text style={styles.signatureLabel}>Signature</Text>
              <Text style={styles.signature}>{record.signature}</Text>
            </View>

            {/* Special Notes */}
            {record.status === 'cooling-down' && (
              <View style={styles.noteBox}>
                <Text style={styles.noteText}>
                  💡 This unstake is in 48-hour cooldown. Come back tomorrow at 14:32 to withdraw.
                </Text>
              </View>
            )}
          </View>
        ))
      )}

      {/* Info Box */}
      <View style={styles.infoBox}>
        <Text style={styles.infoTitle}>💡 How to use this history</Text>
        <Text style={styles.infoText}>
          Each card shows exactly what Clearance displayed to you before you signed.
        </Text>
        <Text style={styles.infoText}>
          If you see a transaction here that you didn't approve, your wallet may have been
          compromised. Move your funds immediately.
        </Text>
      </View>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: DARK_BG,
    padding: 16,
    paddingTop: 40,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: GREEN,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 12,
    color: GRAY,
    marginBottom: 20,
  },
  emptyCard: {
    backgroundColor: DARK_CARD,
    borderWidth: 1,
    borderColor: GREEN,
    borderRadius: 8,
    padding: 30,
    alignItems: 'center',
    marginBottom: 16,
  },
  emptyText: {
    color: GRAY,
    fontSize: 14,
    textAlign: 'center',
  },
  card: {
    backgroundColor: DARK_CARD,
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 8,
    padding: 14,
    marginBottom: 12,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  emoji: {
    fontSize: 20,
    marginRight: 10,
  },
  titleCol: {
    flex: 1,
  },
  actionTitle: {
    color: GREEN,
    fontSize: 13,
    fontWeight: 'bold',
  },
  timestamp: {
    color: GRAY,
    fontSize: 10,
    marginTop: 2,
  },
  statusBadge: {
    fontSize: 10,
    fontWeight: 'bold',
    borderWidth: 1,
    borderRadius: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  amountRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
    marginBottom: 10,
  },
  amountLabel: {
    color: GREEN,
    fontSize: 10,
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  amount: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
    fontFamily: 'monospace',
  },
  plainEnglishBox: {
    backgroundColor: '#000',
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 4,
    padding: 10,
    marginBottom: 10,
  },
  plainEnglish: {
    color: GREEN,
    fontSize: 11,
    lineHeight: 16,
  },
  signatureBox: {
    backgroundColor: '#000',
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 4,
    padding: 8,
    marginBottom: 10,
  },
  signatureLabel: {
    color: GREEN,
    fontSize: 9,
    fontWeight: 'bold',
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  signature: {
    color: '#00ffff',
    fontSize: 9,
    fontFamily: 'monospace',
  },
  noteBox: {
    backgroundColor: 'rgba(251, 191, 36, 0.1)',
    borderLeftWidth: 3,
    borderLeftColor: '#fbbf24',
    paddingLeft: 10,
    paddingRight: 10,
    paddingVertical: 8,
  },
  noteText: {
    color: '#fbbf24',
    fontSize: 10,
    lineHeight: 14,
  },
  infoBox: {
    backgroundColor: DARK_CARD,
    borderWidth: 1,
    borderColor: '#444',
    borderRadius: 8,
    padding: 12,
    marginTop: 20,
  },
  infoTitle: {
    color: GREEN,
    fontSize: 11,
    fontWeight: 'bold',
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  infoText: {
    color: GRAY,
    fontSize: 10,
    lineHeight: 14,
    marginBottom: 6,
  },
});
