import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { PublicKey, TransactionInstruction } from '@solana/web3.js';
import { ClearanceCard } from '../components/ClearanceCard';
import { decodeInstruction, DecodedInstruction } from '../decoders/stakeDecoder';

const DARK_BG = '#0a0a0a';
const GREEN = '#00ff88';
const GRAY = '#666';

interface ClearanceScreenProps {
  wallet: PublicKey | null;
}

export const ClearanceScreen: React.FC<ClearanceScreenProps> = ({ wallet }) => {
  // Mock transaction instruction - in production, this would come from MWA
  const [currentInstruction, setCurrentInstruction] = useState<DecodedInstruction | null>(null);
  const [loading, setLoading] = useState(false);
  const [showExampleCard, setShowExampleCard] = useState(true);

  // Default mock instruction
  const mockInstruction = decodeInstruction(
    new TransactionInstruction({
      keys: [],
      programId: new PublicKey('Stake11111111111111111111111111111111111111'),
      data: Buffer.from([5]), // Deactivate = unstake
    }),
    wallet?.toBase58() || '',
    []
  );

  const handleApprove = () => {
    if (!currentInstruction && !showExampleCard) return;

    setLoading(true);
    // Simulate signing delay
    setTimeout(() => {
      setLoading(false);
      Alert.alert('✓ Transaction Approved', 'Your signature would be sent to Seed Vault now.', [
        {
          text: 'Show Another',
          onPress: () => {
            setCurrentInstruction(null);
            setShowExampleCard(true);
          },
        },
      ]);
    }, 1000);
  };

  const handleReject = () => {
    Alert.alert('✓ Transaction Rejected', 'This transaction was not approved.', [
      {
        text: 'OK',
        onPress: () => {
          setShowExampleCard(true);
          setCurrentInstruction(null);
        },
      },
    ]);
  };

  const showOtherExample = (type: string) => {
    let decoded: DecodedInstruction;

    switch (type) {
      case 'claim':
        decoded = {
          action: 'CLAIM',
          plainEnglish: 'You are claiming 50 SKR in validator rewards.',
          warnings: [
            '✓ This is your earned rewards',
            '✓ SKR will go to your liquid balance',
            '✓ You can immediately stake or send these',
          ],
          amount: 50,
          token: 'SKR',
          program: 'Stake Program (OFFICIAL)',
          isOfficial: true,
          isFirstTime: false,
        };
        break;
      case 'withdraw':
        decoded = {
          action: 'WITHDRAW',
          plainEnglish: 'You are withdrawing 500 SKR that finished cooling down.',
          warnings: [
            '✓ This SKR is now liquid and can be sent',
            '✓ The 48-hour cooldown is complete',
          ],
          amount: 500,
          token: 'SKR',
          program: 'Stake Program (OFFICIAL)',
          isOfficial: true,
          isFirstTime: false,
        };
        break;
      case 'delegate':
        decoded = {
          action: 'DELEGATE',
          plainEnglish: 'You are delegating 1,000 SKR to a Marinade validator.',
          warnings: [
            '✓ Your SKR becomes staked',
            '✓ Rewards start next epoch',
            '⚠️ You cannot move this SKR until you undelegate',
            '✓ You can undelegate and withdraw anytime',
          ],
          amount: 1000,
          token: 'SKR',
          program: 'Marinade Staking (OFFICIAL)',
          isOfficial: true,
          isFirstTime: true,
        };
        break;
      case 'unknown':
      default:
        decoded = {
          action: 'UNKNOWN',
          plainEnglish: 'Unknown program instruction from a new dApp.',
          warnings: [
            '🔴 You have not signed this program before',
            '🔴 Unknown what this will do - high risk',
            'Proceed only if you trust this dApp',
          ],
          program: 'Unknown Program (First Time)',
          isOfficial: false,
          isFirstTime: true,
        };
    }

    setCurrentInstruction(decoded);
    setShowExampleCard(false);
  };

  const display = showExampleCard ? mockInstruction : currentInstruction;

  if (!wallet) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>🔍 Clearance</Text>
        <Text style={styles.subtitle}>Transaction preview</Text>
        <View style={styles.emptyBox}>
          <Text style={styles.emptyText}>Connect your wallet to see transactions</Text>
        </View>
      </View>
    );
  }

  if (!display) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>🔍 Clearance</Text>
        <Text style={styles.subtitle}>Transaction preview</Text>
        <View style={styles.emptyBox}>
          <Text style={styles.emptyText}>Waiting for transaction...</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ClearanceCard
        instruction={display}
        onApprove={handleApprove}
        onReject={handleReject}
        dAppName={showExampleCard ? 'Marinade' : 'Example dApp'}
        loading={loading}
      />

      {/* Examples for testing */}
      {showExampleCard && (
        <View style={styles.examplesSection}>
          <Text style={styles.examplesTitle}>Try other examples:</Text>
          <View style={styles.examplesGrid}>
            <TouchableOpacity
              style={styles.exampleButton}
              onPress={() => showOtherExample('claim')}
            >
              <Text style={styles.exampleButtonText}>🎁 Claim</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.exampleButton}
              onPress={() => showOtherExample('withdraw')}
            >
              <Text style={styles.exampleButtonText}>🪙 Withdraw</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.exampleButton}
              onPress={() => showOtherExample('delegate')}
            >
              <Text style={styles.exampleButtonText}>📌 Delegate</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.exampleButton}
              onPress={() => showOtherExample('unknown')}
            >
              <Text style={styles.exampleButtonText}>⚠️ Unknown</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: DARK_BG,
    paddingHorizontal: 16,
    paddingTop: 20,
    paddingBottom: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: GREEN,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 11,
    color: GRAY,
    marginBottom: 16,
  },
  emptyBox: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#1a1a1a',
    borderWidth: 1,
    borderColor: GREEN,
    borderRadius: 8,
    padding: 20,
  },
  emptyText: {
    color: GRAY,
    fontSize: 14,
    textAlign: 'center',
  },
  examplesSection: {
    marginTop: 16,
    paddingHorizontal: 0,
  },
  examplesTitle: {
    color: GREEN,
    fontSize: 11,
    fontWeight: 'bold',
    textTransform: 'uppercase',
    marginBottom: 10,
  },
  examplesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  exampleButton: {
    flex: 1,
    minWidth: '48%',
    backgroundColor: '#1a1a1a',
    borderWidth: 1,
    borderColor: GREEN,
    borderRadius: 6,
    paddingVertical: 10,
    alignItems: 'center',
  },
  exampleButtonText: {
    color: GREEN,
    fontSize: 12,
    fontWeight: 'bold',
  },
});
