import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator, ScrollView } from 'react-native';
import { PublicKey } from '@solana/web3.js';
import { getBalances, truncateAddress } from '../utils/solana';

const DARK_BG = '#0a0a0a';
const DARK_CARD = '#1a1a1a';
const GREEN = '#00ff88';
const GRAY = '#666';
const YELLOW = '#fbbf24';

interface HomeScreenProps {
  wallet: PublicKey | null;
  onConnect: () => void;
  onDisconnect: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({ wallet, onConnect, onDisconnect }) => {
  const [sol, setSol] = useState<number | null>(null);
  const [skr, setSkr] = useState<{
    liquid: number;
    staked: number;
    coolingDown: number;
  } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (wallet) {
      fetchBalances();
    }
  }, [wallet]);

  const fetchBalances = async () => {
    if (!wallet) return;
    setLoading(true);
    setError(null);
    try {
      const balances = await getBalances(wallet);
      setSol(balances.sol);
      setSkr({
        liquid: balances.skr.liquid,
        staked: balances.skr.staked,
        coolingDown: balances.skr.coolingDown,
      });
    } catch (err) {
      setError('Failed to fetch balances');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const totalSkr = skr ? skr.liquid + skr.staked + skr.coolingDown : 0;

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <Text style={styles.title}>🔐 Clearance</Text>
      <Text style={styles.subtitle}>See what you're signing, every time</Text>

      {/* Wallet Card */}
      <View style={styles.card}>
        <Text style={styles.label}>Wallet Connection</Text>
        {wallet ? (
          <>
            <Text style={styles.address}>{truncateAddress(wallet.toBase58())}</Text>
            <Text style={styles.statusConnected}>✓ Connected to Seeker</Text>
            <TouchableOpacity style={styles.buttonDisconnect} onPress={onDisconnect}>
              <Text style={styles.buttonText}>Disconnect</Text>
            </TouchableOpacity>
          </>
        ) : (
          <>
            <Text style={styles.statusDisconnected}>✗ Not Connected</Text>
            <TouchableOpacity style={styles.buttonConnect} onPress={onConnect}>
              <Text style={styles.buttonText}>Connect Seed Vault</Text>
            </TouchableOpacity>
          </>
        )}
      </View>

      {/* SOL Balance Card */}
      {wallet && (
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Text style={styles.label}>SOL Balance</Text>
            <TouchableOpacity onPress={fetchBalances}>
              <Text style={styles.refreshButton}>🔄</Text>
            </TouchableOpacity>
          </View>
          {loading && !sol ? (
            <ActivityIndicator color={GREEN} size="large" />
          ) : error ? (
            <Text style={styles.error}>{error}</Text>
          ) : sol !== null ? (
            <>
              <Text style={styles.balanceLarge}>{sol.toFixed(4)} SOL</Text>
              <Text style={styles.balanceNote}>For transaction fees</Text>
            </>
          ) : null}
        </View>
      )}

      {/* SKR Balance Card - The Critical One */}
      {wallet && (
        <View style={[styles.card, styles.skrCard]}>
          <View style={styles.cardHeader}>
            <Text style={styles.label}>SKR Balance</Text>
            <Text style={styles.totalBadge}>{totalSkr.toFixed(0)} SKR</Text>
          </View>

          {loading && !skr ? (
            <ActivityIndicator color={GREEN} size="large" />
          ) : error ? (
            <Text style={styles.error}>{error}</Text>
          ) : skr ? (
            <>
              {/* Liquid - Can move now */}
              <View style={styles.balanceRow}>
                <Text style={styles.balanceLabel}>Liquid (Ready to move)</Text>
                <Text style={[styles.balanceAmount, { color: GREEN }]}>
                  {skr.liquid.toFixed(0)}
                </Text>
              </View>

              {/* Staked - Earning rewards */}
              {skr.staked > 0 && (
                <View style={[styles.balanceRow, styles.stakedRow]}>
                  <Text style={styles.balanceLabel}>Staked (Earning rewards)</Text>
                  <Text style={[styles.balanceAmount, { color: '#4ade80' }]}>
                    {skr.staked.toFixed(0)}
                  </Text>
                </View>
              )}

              {/* Cooling Down - In 48h cooldown */}
              {skr.coolingDown > 0 && (
                <View style={[styles.balanceRow, styles.coolingRow]}>
                  <View>
                    <Text style={styles.balanceLabel}>Cooling Down</Text>
                    <Text style={styles.cooldownNote}>⏱️ Available in 48 hours</Text>
                  </View>
                  <Text style={[styles.balanceAmount, { color: YELLOW }]}>
                    {skr.coolingDown.toFixed(0)}
                  </Text>
                </View>
              )}

              <Text style={styles.balanceNote}>
                Liquid: Can send, trade, or restake anytime
              </Text>
            </>
          ) : null}
        </View>
      )}

      {/* Info Card */}
      <View style={styles.infoCard}>
        <Text style={styles.infoTitle}>Why Clearance?</Text>
        <Text style={styles.infoText}>
          🔐 When you sign SKR transactions, Clearance shows you exactly what will happen in
          plain English.
        </Text>
        <Text style={styles.infoText}>
          ⚠️ Oct 1, 2026: A user lost their SKR after blindly signing. Clearance prevents this.
        </Text>
        <Text style={styles.infoText}>
          ✓ Seed Vault still signs. Clearance just makes it readable.
        </Text>
      </View>

      {/* How it works */}
      <View style={styles.howitWorks}>
        <Text style={styles.infoTitle}>How Clearance Works</Text>
        <Text style={styles.stepText}>1️⃣ You use a dApp and sign a transaction</Text>
        <Text style={styles.stepText}>2️⃣ Before you approve in Seed Vault...</Text>
        <Text style={styles.stepText}>3️⃣ Clearance shows you what will happen</Text>
        <Text style={styles.stepText}>4️⃣ Approve only if it makes sense</Text>
      </View>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: DARK_BG,
    padding: 16,
    paddingTop: 40,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: GREEN,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 12,
    color: GRAY,
    marginBottom: 24,
  },
  card: {
    backgroundColor: DARK_CARD,
    borderWidth: 1,
    borderColor: GREEN,
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
  },
  skrCard: {
    borderColor: YELLOW,
    borderWidth: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  label: {
    color: GREEN,
    fontSize: 12,
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  refreshButton: {
    fontSize: 18,
  },
  totalBadge: {
    color: YELLOW,
    fontSize: 14,
    fontWeight: 'bold',
    backgroundColor: 'rgba(251, 191, 36, 0.1)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 4,
  },
  address: {
    color: '#00ffff',
    fontSize: 11,
    fontFamily: 'monospace',
    backgroundColor: '#000',
    padding: 8,
    borderRadius: 4,
    marginBottom: 8,
  },
  statusConnected: {
    color: '#4ade80',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 12,
  },
  statusDisconnected: {
    color: '#ef4444',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 12,
  },
  buttonConnect: {
    backgroundColor: GREEN,
    paddingVertical: 12,
    borderRadius: 6,
    alignItems: 'center',
  },
  buttonDisconnect: {
    backgroundColor: '#ef4444',
    paddingVertical: 12,
    borderRadius: 6,
    alignItems: 'center',
  },
  buttonText: {
    color: '#000',
    fontWeight: 'bold',
    fontSize: 14,
  },
  balanceLarge: {
    color: GREEN,
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  balanceNote: {
    color: GRAY,
    fontSize: 11,
    marginTop: 8,
  },
  balanceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  stakedRow: {
    backgroundColor: 'rgba(74, 222, 128, 0.05)',
  },
  coolingRow: {
    backgroundColor: 'rgba(251, 191, 36, 0.05)',
  },
  balanceLabel: {
    color: '#fff',
    fontSize: 13,
    fontWeight: '500',
  },
  cooldownNote: {
    color: GRAY,
    fontSize: 10,
    marginTop: 2,
  },
  balanceAmount: {
    fontSize: 16,
    fontWeight: 'bold',
    fontFamily: 'monospace',
  },
  error: {
    color: '#ef4444',
    fontSize: 12,
    marginVertical: 8,
  },
  infoCard: {
    backgroundColor: DARK_CARD,
    borderWidth: 1,
    borderColor: '#444',
    borderRadius: 8,
    padding: 14,
    marginBottom: 16,
  },
  howitWorks: {
    backgroundColor: DARK_CARD,
    borderLeftWidth: 3,
    borderLeftColor: GREEN,
    paddingLeft: 12,
    paddingRight: 14,
    paddingVertical: 12,
    marginBottom: 16,
    borderRadius: 0,
  },
  infoTitle: {
    color: GREEN,
    fontSize: 12,
    fontWeight: 'bold',
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  infoText: {
    color: GRAY,
    fontSize: 11,
    lineHeight: 16,
    marginBottom: 6,
  },
  stepText: {
    color: '#fff',
    fontSize: 11,
    lineHeight: 18,
    marginBottom: 4,
  },
});
