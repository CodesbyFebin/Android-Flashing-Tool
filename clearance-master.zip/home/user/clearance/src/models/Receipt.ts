export type SettlementStatus = 'pending' | 'confirmed' | 'finalized' | 'failed';

export interface Receipt {
  actionId: string;
  evidenceDigest: string;
  transactionSignature: string;
  settlementStatus: SettlementStatus;
  observedAt: number;
}

export function createReceipt(
  actionId: string,
  evidenceDigest: string,
  signature: string
): Receipt {
  return {
    actionId,
    evidenceDigest,
    transactionSignature: signature,
    settlementStatus: 'pending',
    observedAt: Date.now(),
  };
}
