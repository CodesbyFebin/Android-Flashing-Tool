export type ActionStatus = 'draft' | 'reviewed' | 'authorized' | 'settled' | 'rejected';

export interface Action {
  id: string;
  taskId: string;
  recipient: string;
  mint: string;
  rawAmount: string;
  decimals: number;
  network: 'devnet' | 'mainnet-beta';
  status: ActionStatus;
  createdAt: number;
}

export function createAction(
  taskId: string,
  recipient: string,
  mint: string,
  rawAmount: string,
  decimals: number,
  network: 'devnet' | 'mainnet-beta' = 'devnet'
): Action {
  return {
    id: Math.random().toString(36).substring(7),
    taskId,
    recipient,
    mint,
    rawAmount,
    decimals,
    network,
    status: 'draft',
    createdAt: Date.now(),
  };
}
