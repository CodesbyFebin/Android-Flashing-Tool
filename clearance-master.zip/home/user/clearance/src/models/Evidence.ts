export interface Evidence {
  actionId: string;
  photoPath: string;
  photoSha256: string;
  note: string;
  capturedAt: number;
  manifestSha256: string;
}

export function canonicalManifest(e: Evidence): string {
  return JSON.stringify([
    ['actionId', e.actionId],
    ['photoSha256', e.photoSha256],
    ['note', e.note],
    ['capturedAt', e.capturedAt],
  ]);
}

export interface ManifestData {
  actionId: string;
  photoSha256: string;
  note: string;
  capturedAt: number;
}
