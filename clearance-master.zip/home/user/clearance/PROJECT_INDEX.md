# Clearance Project Index

**An Android app for explaining Solana payments before signing and producing verifiable receipts.**

---

## 📚 Documentation Map

### For the Impatient
- **README.md** — Quick start (5 min read)
  - What is Clearance?
  - How to run it
  - The problem and solution
  - Feature roadmap

### For Builders
- **DEVELOPMENT_PROGRESS.md** — Project status (3 min read)
  - What's done ✅
  - What's left ⏳
  - Next immediate steps 🚀
  - Timeline to Oct 8 📅

### For Architects
- **TECHNICAL_WHITEPAPER.md** — Deep dive (15 min read)
  - Complete system design
  - Domain models (Action, Evidence, Receipt)
  - Service architecture
  - Security design (evidence integrity, review binding)
  - Demo workflow (8 steps)
  - Career positioning

### For Judges
- **PITCH.md** (forthcoming) — 10-slide deck
  - The problem (Oct 1 drain)
  - The solution (Clearance)
  - Why it wins (stickiness, innovation, scope)
  - Demo footage (in video)
  - Call to action

---

## 🏗️ Codebase Structure

```
clearance/
├── 📄 Docs
│   ├── README.md                      ← START HERE
│   ├── TECHNICAL_WHITEPAPER.md        ← Deep dive
│   ├── DEVELOPMENT_PROGRESS.md        ← Status dashboard
│   └── PROJECT_INDEX.md               ← This file
│
├── 📱 App (Expo/React Native)
│   ├── App.tsx                        ← Tab navigator + wallet state
│   ├── app.json                       ← Expo config
│   ├── package.json                   ← Dependencies
│   ├── tsconfig.json                  ← TypeScript config
│   ├── babel.config.js                ← Babel preset
│   │
│   └── src/
│       ├── screens/
│       │   ├── HomeScreen.tsx         ← Wallet + balances
│       │   ├── ClearanceScreen.tsx    ← Transaction preview
│       │   └── ProofScreen.tsx        ← Receipt history
│       │
│       ├── components/
│       │   └── ClearanceCard.tsx      ← Main product UI
│       │
│       ├── models/                    ← Domain objects
│       │   ├── Action.ts              ← Payment request
│       │   ├── Evidence.ts            ← Photo + note + hash
│       │   └── Receipt.ts             ← Settlement record
│       │
│       ├── services/
│       │   ├── mwa.ts                 ← Mobile Wallet Adapter
│       │   ├── solana.ts              ← RPC queries, balances
│       │   ├── evidence.ts            ← Camera, file, hashing
│       │   ├── reviewBinding.ts       ← Transaction integrity
│       │   ├── settlement.ts          ← RPC status polling
│       │   ├── stakeDecoder.ts        ← Instruction parsing
│       │   ├── store.ts               ← AsyncStorage persistence
│       │   └── validators.ts          ← Input validation (TBD)
│       │
│       └── utils/
│           └── solana.ts              ← Helper functions
│
└── android/                           ← Native modules (future)
    └── build.gradle                   ← Kotlin configuration
```

---

## 🔄 Data Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    USER INTERACTION                         │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
                 ┌─────────────────────────┐
                 │  1. Connect Wallet      │
                 │  (MWA / Seed Vault)     │
                 └─────────────────────────┘
                              │
                              ▼
                 ┌─────────────────────────┐
                 │  2. Show Balances       │
                 │  (SOL + SKR breakdown)  │
                 └─────────────────────────┘
                              │
                              ▼
                 ┌─────────────────────────┐
                 │  3. Scan Task QR        │
                 │  (Parse Action)         │
                 └─────────────────────────┘
                              │
                              ▼
                 ┌─────────────────────────┐
                 │  4. Capture Evidence    │
                 │  (Photo + note + hash)  │
                 └─────────────────────────┘
                              │
                              ▼
                 ┌─────────────────────────┐
                 │  5. Build Transaction   │
                 │  (RPC simulation)       │
                 └─────────────────────────┘
                              │
                              ▼
         ┌────────────────────────────────────────┐
         │  6. Hash Transaction (Review Binding)  │
         │  (Prepare for review verification)     │
         └────────────────────────────────────────┘
                              │
                              ▼
         ┌────────────────────────────────────────┐
         │  7. Display Clearance Card             │
         │  (Recipient + Amount + Warnings)       │
         └────────────────────────────────────────┘
                              │
                 ┌────────────┴────────────┐
                 │                         │
          REJECT │                         │ APPROVE
                 │                         │
                 ▼                         ▼
    ┌─────────────────────┐    ┌──────────────────────────┐
    │  Action.rejected    │    │  8. Re-verify Message   │
    │  (No signature)     │    │  (assertUnchanged)       │
    └─────────────────────┘    └──────────────────────────┘
                                         │
                                         ▼
                            ┌──────────────────────────┐
                            │  9. Sign Transaction    │
                            │  (MWA wallet signing)    │
                            └──────────────────────────┘
                                         │
                                         ▼
                            ┌──────────────────────────┐
                            │  10. Observe Settlement  │
                            │  (RPC status polling)    │
                            └──────────────────────────┘
                                         │
                                         ▼
                            ┌──────────────────────────┐
                            │  11. Create Receipt      │
                            │  (Signature + Digest)    │
                            └──────────────────────────┘
                                         │
                                         ▼
                            ┌──────────────────────────┐
                            │  12. Display in Proof    │
                            │  (Settlement status)     │
                            └──────────────────────────┘
                                         │
                                         ▼
                            ┌──────────────────────────┐
                            │  13. Export Receipt      │
                            │  (JSON verification)     │
                            └──────────────────────────┘
```

---

## 🎯 Core Concepts

### Action (models/Action.ts)
Payment request from QR code or manual entry.

```
draft → reviewed → authorized → settled
(or rejected)
```

### Evidence (models/Evidence.ts)
Photo + note with cryptographic manifest.

```
actionId + photoSha256 + note + capturedAt
↓
canonicalManifest (deterministic JSON)
↓
manifestSha256 (verifiable hash)
```

### Receipt (models/Receipt.ts)
Settlement record linking evidence to on-chain transaction.

```
actionId + evidenceDigest + signature + settlementStatus
```

### Review Binding (services/reviewBinding.ts)
Hashes transaction before review; re-checks before signing to prevent MITM modification.

```
hashTransaction(txData) → messageHash
↓
prepareReview(messageHash, network, account)
↓
[User reviews and approves]
↓
assertUnchanged(txData, review) — throws if modified
↓
Sign in wallet
```

### Settlement Observation (services/settlement.ts)
RPC-based polling of transaction status.

```
pending → confirmed → finalized
(or failed)
```

---

## 🚀 Getting Started

### Install & Run
```bash
cd /home/user/clearance
npm install                # Already done ✅
npm start                  # Start Expo dev server
# Press 'a' for Android emulator
```

### Project Structure
- **HomeScreen**: Wallet + balances
- **ClearanceScreen**: Transaction preview + examples
- **ProofScreen**: Receipt history + settlement status

### Key Features Implemented
1. ✅ MWA wallet connection (mock)
2. ✅ Balance display (SOL + SKR)
3. ✅ Transaction decoder (stake, transfer, etc)
4. ✅ Evidence capture (camera + SHA-256)
5. ✅ Review binding (message integrity)
6. ✅ Settlement observation (RPC polling)
7. ✅ Receipt persistence (AsyncStorage)
8. ✅ Dark UI theme (green + black)
9. ✅ Clearance card (main product)

---

## 📊 File Sizes & Complexity

| File | Lines | Purpose | Complexity |
|------|-------|---------|------------|
| App.tsx | 106 | Tab navigation | Low |
| HomeScreen.tsx | 361 | Wallet + balances | Medium |
| ClearanceScreen.tsx | 273 | Transaction preview | High |
| ProofScreen.tsx | 348 | Receipt history | High |
| ClearanceCard.tsx | 290 | Main product UI | High |
| stakeDecoder.ts | 340 | Instruction parsing | High |
| evidence.ts | 87 | Photo capture + hash | High |
| reviewBinding.ts | 41 | Message hashing | Medium |
| settlement.ts | 70 | RPC polling | Medium |
| Action.ts | 28 | Domain model | Low |
| Evidence.ts | 20 | Domain model | Low |
| Receipt.ts | 20 | Domain model | Low |
| store.ts | 68 | AsyncStorage | Medium |
| **TOTAL** | **~2,052** | **Full app** | **Medium-High** |

---

## 🔐 Security Features

- ✅ Evidence SHA-256 computed locally
- ✅ Manifest canonicalization prevents reordering attacks
- ✅ Review binding hashes transaction message
- ✅ assertUnchanged throws on modification
- ✅ Photos stored in sandboxed DocumentDirectory
- ✅ Settlement verification via public RPC
- ✅ No private keys logged or stored
- ✅ Receipt export for independent verification

---

## 📦 Dependencies

### Runtime
- `expo` (50.0.0) — React Native framework
- `react-native` (0.73.0) — Mobile UI library
- `@solana/web3.js` (1.91.0) — Blockchain interaction
- `expo-crypto` (12.0.0) — SHA-256 hashing
- `expo-file-system` (15.0.0) — File I/O
- `expo-image-picker` (14.0.0) — Camera access
- `@react-native-async-storage/async-storage` (1.21.0) — Persistence
- `@react-navigation/bottom-tabs` (6.5.11) — Tab navigation

### Dev
- `typescript` (5.3.3) — Type safety
- `@types/react` (18.2.45) — React types
- `@babel/core` (7.20.0) — Babel compiler

---

## 🎬 Demo Script (3 minutes)

1. **Connect** (15s)
   - Tap "Connect Seed Vault"
   - Show address + SOL + SKR balance

2. **Capture** (30s)
   - Scan task QR (or use preset)
   - Take a photo with camera
   - Add a note

3. **Review** (30s)
   - Go to Clearance tab
   - Show unstake example
   - Display clearance card with warnings

4. **Reject** (15s)
   - Tap "REJECT"
   - Show confirmation alert

5. **Approve** (30s)
   - Go back, show same transaction
   - Tap "APPROVE"
   - (Mock) show wallet signing

6. **Settle** (15s)
   - Go to Proof tab
   - Show new receipt with pending status
   - Wait a few seconds, status updates to confirmed

7. **Export** (15s)
   - Tap "📤 Export Receipt"
   - Show JSON receipt with signature + digest

**Total**: ~3 minutes

---

## 🏆 Competitive Positioning

### Why Clearance Wins

| Dimension | Clearance | Others |
|-----------|-----------|--------|
| **Real Pain** | Oct 1 drain (happened this week) | Generic "improve UX" |
| **Stickiness** | 10+ uses/month (every stake/unstake) | One-time savings tool |
| **Innovation** | First readability layer for SKR | Standard wallet UI |
| **Scope** | 4-day MVP, clear scope | Weeks of feature creep |
| **Platform** | Native Seeker integration | Generic mobile app |

### Hiring Value

Clearance demonstrates:
- Android app development (Expo, React Native)
- Blockchain integration (Solana, RPC, Web3.js)
- Applied cryptography (SHA-256, manifest signing)
- Security design (review binding, evidence integrity)
- UX for high-stakes decisions

**Target Role**: Android System Engineer (Solana Mobile)
**Salary Range**: $138k–$159k

---

## 📅 Sprint Timeline

| Date | Focus | Deliverable |
|------|-------|-------------|
| **Oct 4** | Architecture + models | MVP scaffold ✅ |
| **Oct 5** | Local testing | Working emulator build |
| **Oct 6** | GitHub push | Public repo + source |
| **Oct 7** | Demo + pitch | 3-min video + 10-slide deck |
| **Oct 8** | Final submission | APK + repo + video + deck |

---

## 🎓 Learning Path

By reading these docs in order, you'll understand:

1. **README.md** (5 min)
   - What is Clearance?
   - How to run it locally

2. **DEVELOPMENT_PROGRESS.md** (3 min)
   - Current status
   - Next steps

3. **TECHNICAL_WHITEPAPER.md** (15 min)
   - Full architecture
   - Why each design choice

4. **PROJECT_INDEX.md** (this file, 5 min)
   - Data flow
   - File structure
   - Quick reference

5. **Source Code** (30 min)
   - Start with App.tsx
   - Read each screen
   - Study services

---

## 🚨 Decision Gates

### Can the app start in Android emulator?
```bash
npm start
# Press 'a' for Android
# Expected: Three tabs appear, no crashes
```

**If YES** → Proceed to full testing  
**If NO** → Debug compilation/runtime errors

### Can we connect a mock wallet?
Check HomeScreen → should show address after connect

### Can we decode transactions?
Check ClearanceScreen → should show proper recipient/amount

### Can we persist receipts?
Check ProofScreen → should show history (wait for RPC status)

---

## 📞 Support

| Question | Answer |
|----------|--------|
| Where is the feature X? | Check TECHNICAL_WHITEPAPER.md section 5 |
| How do I test feature Y? | See DEVELOPMENT_PROGRESS.md testing section |
| What's the next step? | See DEVELOPMENT_PROGRESS.md "Next Steps (Immediate)" |
| How do I submit? | See README.md "Submission Checklist" |

---

## ✨ Final Checklist

Before final submission (Oct 8):

- [ ] App runs in Android emulator without crashes
- [ ] All three screens render correctly
- [ ] Wallet connection works (mock or real)
- [ ] Example transactions decode
- [ ] Clearance card displays correctly
- [ ] Reject/approve buttons work
- [ ] Settlement polling updates status
- [ ] Receipts persist across sessions
- [ ] Export functionality works
- [ ] No TypeScript errors in Expo build
- [ ] GitHub repo has clean commit history
- [ ] Demo video is 3 minutes or less
- [ ] Pitch deck is 10 slides
- [ ] README.md is complete
- [ ] TECHNICAL_WHITEPAPER.md is comprehensive

---

**Built for CLOCK IN Solana Mobile Hackathon 2026**

**Clearance. See what you approve. Prove what happened.** 🔍

---

## 📍 You Are Here

```
Start → README.md → DEVELOPMENT_PROGRESS.md → THIS FILE → Code
                                                      ↓
                                            TECHNICAL_WHITEPAPER.md
```

**Next**: Read DEVELOPMENT_PROGRESS.md for "Next Steps (Immediate)"
