# Clearance Technical Whitepaper

**See what you approve. Prove what happened.**

---

## 1. Executive Summary

**Problem**: Solana users approve transactions without understanding consequences. DePIN operators face separate records for work, reporting, and payment.

**Solution**: Clearance — an Android app that explains Solana payments before signing and connects settlement to cryptographically-verified receipts.

**Why It Wins**:
- Solves Oct 1, 2026 drain event (real, public pain point)
- Stickiness: Users return 10+ times/month (every stake/unstake/claim)
- Evidence model extends to DePIN task verification
- Built on Seeker hardware (native advantage)
- Demonstrates Android/Kotlin security expertise

**Submission**: APK (device), GitHub repo, demo video, pitch deck by Oct 8, 2026.

---

## 2. Architecture Overview

### 2.1 Modular Structure

```
ClearanceApp/
├── src/
│   ├── screens/
│   │   ├── HomeScreen.tsx       (Wallet + balances)
│   │   ├── ClearanceScreen.tsx  (Transaction preview)
│   │   └── ProofScreen.tsx      (Receipt audit trail)
│   ├── components/
│   │   └── ClearanceCard.tsx    (Main product UI)
│   ├── models/
│   │   ├── Action.ts            (Payment request)
│   │   ├── Evidence.ts          (Photo + note + hash)
│   │   └── Receipt.ts           (Settlement record)
│   ├── services/
│   │   ├── mwa.ts               (Mobile Wallet Adapter)
│   │   ├── solana.ts            (RPC, decoding)
│   │   ├── evidence.ts          (Camera, hashing)
│   │   ├── reviewBinding.ts     (Transaction integrity)
│   │   ├── settlement.ts        (RPC status observation)
│   │   ├── stakeDecoder.ts      (Instruction decoding)
│   │   └── store.ts             (AsyncStorage persistence)
│   ├── utils/
│   │   └── validators.ts        (Input validation)
│   └── App.tsx                  (Tab navigation)
├── android/                     (Future: Kotlin modules)
├── app.json                     (Expo config)
├── package.json                 (Dependencies)
└── README.md                    (MVP guide)
```

### 2.2 Data Flow

```
QR Code → Parse Action
       ↓
   Capture Evidence (photo + note)
       ↓
   Hash Evidence (SHA-256 manifest)
       ↓
   Build Transaction
       ↓
   Hash Transaction (review binding)
       ↓
   Display Clearance Card
       ↓
   User Approves / Rejects
       ↓
   Sign in Wallet (MWA)
       ↓
   Observe Settlement (RPC polling)
       ↓
   Create Receipt (signature + digest + status)
       ↓
   Store Receipt + Evidence
       ↓
   Display in Proof Screen
```

---

## 3. Core Domain Models

### 3.1 Action (models/Action.ts)

Payment request with lifecycle.

```typescript
type ActionStatus = 'draft' | 'reviewed' | 'authorized' | 'settled' | 'rejected';

interface Action {
  id: string;              // UUID
  taskId: string;          // From QR code
  recipient: string;       // Destination wallet
  mint: string;            // Token mint (e.g., SKR)
  rawAmount: string;       // Decimal string
  decimals: number;        // Token decimals
  network: 'devnet' | 'mainnet-beta';
  status: ActionStatus;
  createdAt: number;       // Unix timestamp
}
```

**Lifecycle**: `draft` → `reviewed` → `authorized` → `settled`

---

### 3.2 Evidence (models/Evidence.ts)

Photo + note with cryptographic manifest.

```typescript
interface Evidence {
  actionId: string;
  photoPath: string;          // Local file
  photoSha256: string;        // SHA-256 of photo bytes
  note: string;               // Operator note
  capturedAt: number;         // Unix timestamp
  manifestSha256: string;     // SHA-256 of canonical manifest
}

function canonicalManifest(e: Evidence): string {
  return JSON.stringify([
    ['actionId', e.actionId],
    ['photoSha256', e.photoSha256],
    ['note', e.note],
    ['capturedAt', e.capturedAt]
  ]);
}
```

**Key Property**: Manifest SHA-256 is deterministic and reproducible.

---

### 3.3 Receipt (models/Receipt.ts)

Settlement record linking evidence to on-chain transaction.

```typescript
type SettlementStatus = 'pending' | 'confirmed' | 'finalized' | 'failed';

interface Receipt {
  actionId: string;
  evidenceDigest: string;         // manifestSha256
  transactionSignature: string;
  settlementStatus: SettlementStatus;
  observedAt: number;             // Observation timestamp
}
```

**Verification**: User can recompute evidence manifest hash to verify receipt integrity.

---

## 4. Core Services

### 4.1 Evidence Service (services/evidence.ts)

Captures photo via `expo-image-picker`, hashes via `expo-crypto`.

```typescript
export async function captureEvidence(
  actionId: string,
  note: string
): Promise<Evidence>

// Returns:
{
  actionId: "task-123",
  photoPath: "/data/evidence/task-123_1696416000.jpg",
  photoSha256: "a3f5c9...",
  note: "Site inspection complete",
  capturedAt: 1696416000,
  manifestSha256: "8b2d1f..."
}
```

**Security**: Photo saved to `FileSystem.documentDirectory` (sandboxed).

---

### 4.2 Review Binding (services/reviewBinding.ts)

Hashes transaction before review, re-checks before signing.

```typescript
// 1. Build transaction
const tx = buildTransaction(...);
const txData = serializeTransaction(tx);

// 2. Prepare review (hash the message)
const review = await prepareReview(txData, 'devnet', walletAddress);

// 3. Display Clearance Card
// User reviews and approves

// 4. Before signing, assert message unchanged
await assertUnchanged(txData, review);

// If message changed, throws MESSAGE_CHANGED
```

**Protection**: Prevents MITM modification between review and signing.

---

### 4.3 Settlement Observation (services/settlement.ts)

RPC-based polling of transaction status.

```typescript
export async function observeSettlement(
  signature: string,
  network: 'devnet' | 'mainnet-beta' = 'devnet'
): Promise<SettlementStatus>

// Returns immediately with:
// - 'pending' (not seen on chain)
// - 'confirmed' (seen, 30+ confirmations)
// - 'finalized' (seen, >32 confirmations)
// - 'failed' (error execution)
```

**Reliability**: Uses Solana RPC `getSignatureStatuses` with connection pooling.

---

### 4.4 Instruction Decoder (services/stakeDecoder.ts)

Parses Solana instruction data into plain English.

```typescript
type DecodedInstruction =
  | { kind: 'transferChecked'; mint: string; amount: bigint; decimals: number; ... }
  | { kind: 'unsupported'; programId: string; reason: string }

export function decodeInstruction(instruction: any): DecodedInstruction
```

**Coverage**: TransferChecked (SPL token), Stake program, Marinade.

---

### 4.5 Persistence (services/store.ts)

AsyncStorage-backed persistence.

```typescript
export async function saveAction(action: Action): Promise<void>
export async function getAction(id: string): Promise<Action | null>

export async function saveEvidence(evidence: Evidence): Promise<void>
export async function getReceipts(): Promise<Receipt[]>
```

---

## 5. UI Screens

### 5.1 Home Screen

Wallet connection and balance display.

```
┌─────────────────────────────┐
│ 🔐 Clearance                │
│ See what you're signing...  │
├─────────────────────────────┤
│ Wallet Connection           │
│ ✓ So11111...11112           │
│ ✓ Connected to Seeker       │
│ [Disconnect]                │
├─────────────────────────────┤
│ SOL Balance                 │
│ 2.1234 SOL                  │
│ For transaction fees        │
├─────────────────────────────┤
│ SKR Balance (CRITICAL)      │
│ Total: 1,500 SKR            │
│ Liquid:   500 (can send)    │
│ Staked: 1,000 (earning)     │
│ Cooling:    0 (⏱️ 48h wait)  │
├─────────────────────────────┤
│ Info: Why Clearance?        │
│ ...                         │
└─────────────────────────────┘
```

---

### 5.2 Clearance Screen

Transaction preview with decoded instructions.

```
┌──────────────────────────────────┐
│ CLEARANCE                        │
│                                  │
│ 📍 STAKE                         │
│                                  │
│ You are staking 1,000 SKR.       │
│ Rewards start next epoch.        │
│ You cannot move this until unstaked.
│                                  │
│ Amount: 1,000 SKR                │
│ To: Marinade (Guardian)          │
│ Program: Stake Program (OFFICIAL)│
│ Fee: ~0.00025 SOL                │
│                                  │
│ [← REJECT]      [APPROVE →]      │
└──────────────────────────────────┘
```

---

### 5.3 Proof Screen

Receipt history with settlement status.

```
┌───────────────────────────────────┐
│ 📜 Proof                          │
│ Verified receipts                │
├───────────────────────────────────┤
│ task-456                  ✓ Finalized
│ Oct 4, 2:30 PM                   │
├───────────────────────────────────┤
│ Signature: 4ade80...aef89d        │
│ Evidence: 8b2d1f...3c4a7e         │
│                                   │
│ 📷 Photo: a3f5c9...               │
│ 📝 Note: Site inspection complete │
│                                   │
│ [📤 Export Receipt]               │
├───────────────────────────────────┤
│ task-123                  ✓ Confirmed
│ Oct 3, 10:15 AM                  │
│ ...                               │
└───────────────────────────────────┘
```

---

## 6. Security Design

### 6.1 Evidence Integrity

- **Capture**: Photo saved to sandboxed DocumentDirectory
- **Hash**: SHA-256 of photo bytes via `expo-crypto`
- **Manifest**: Canonical JSON array hashed to prevent reordering
- **Verification**: User can recompute hash offline to verify receipt

### 6.2 Review Binding

- **Hash on Review**: Transaction serialized and SHA-256 hashed
- **Check Before Sign**: Re-hash before sending to wallet
- **Detection**: If modified, throws `MESSAGE_CHANGED`

### 6.3 Wallet Integration

- **MWA Protocol**: Uses `transact()` → `authorize()` flow
- **No Key Export**: Wallet signs within its own context
- **Signature Verification**: User can verify signature on-chain via explorer

### 6.4 Settlement Observation

- **RPC Polling**: Uses public Solana RPC (devnet/mainnet)
- **Status Verification**: Checks signature status every 1-5 seconds
- **Timeout Handling**: Caps at 60 attempts (1 minute max wait)

---

## 7. Demo Workflow

### Step 1: Connect Wallet
- **Action**: User taps "Connect Seed Vault"
- **Result**: HomeScreen shows address + balances

### Step 2: Scan Task
- **Action**: User scans QR code (or manually enters task)
- **Result**: Action record created, status = 'draft'

### Step 3: Capture Evidence
- **Action**: User takes photo, adds note
- **Result**: Evidence saved + manifest hashed

### Step 4: Review Payment
- **Action**: ClearanceCard displays recipient + amount + decoded instructions
- **Result**: Transaction message is hashed (review binding active)

### Step 5: Reject Invalid Request
- **Action**: User taps "REJECT" on a deliberately invalid request
- **Result**: Action marked 'rejected', no signature sent

### Step 6: Authorize Valid Request
- **Action**: User taps "APPROVE" on valid request
- **Result**: 
  - Transaction message re-verified (assertUnchanged passes)
  - Wallet signs via MWA
  - Settlement observation begins

### Step 7: Inspect Settlement
- **Action**: Proof screen polls RPC every 5 seconds
- **Result**: Status updates from 'pending' → 'confirmed' → 'finalized'

### Step 8: Verify Receipt
- **Action**: User taps "Export Receipt"
- **Result**: JSON export shows signature + evidence digest + status

---

## 8. Submission Checklist

### Build & APK
- [ ] `npm install` completes without errors
- [ ] `npm start` launches Expo dev server
- [ ] `npm run android` opens app in emulator
- [ ] All three screens render correctly
- [ ] No TypeScript compilation errors

### Functionality
- [ ] Wallet connects via MWA (mock or real)
- [ ] SOL + SKR balances display
- [ ] Example transactions decode correctly
- [ ] Clearance card shows exact recipient, amount, warnings
- [ ] Reject button works without crashing
- [ ] Approve button prepares review binding
- [ ] Settlement observation checks RPC status
- [ ] Proof screen displays receipts with status badges
- [ ] Export functionality shows complete receipt JSON

### Security
- [ ] Photos saved to sandboxed directory
- [ ] Evidence SHA-256 computed and stored
- [ ] Review binding hashes transaction message
- [ ] assertUnchanged throws on modification
- [ ] No private keys logged

### Documentation
- [ ] GitHub repo has clean commit history
- [ ] README.md covers quick start
- [ ] TECHNICAL_WHITEPAPER.md explains architecture
- [ ] Commit messages are clear and descriptive

### Demo & Pitch
- [ ] Demo video: 3 minutes max
- [ ] Shows: connect → capture → review → reject → approve → settle → export
- [ ] Pitch deck: 10 slides
- [ ] Covers: problem, solution, why it wins, demo, submission timeline

---

## 9. Testing Instructions

### Local Emulator
```bash
cd /home/user/clearance
npm start
# Press 'a' to open Android emulator
```

### Physical Device
```bash
npm run android  # Builds and installs
# Test on Seeker or Android device
```

### Manual Test Cases

| Case | Action | Expected Result |
|------|--------|-----------------|
| Connect wallet | Tap "Connect" | HomeScreen shows address + SOL/SKR balance |
| Reject transaction | Tap "REJECT" | Alert shown, no wallet prompt |
| Approve transaction | Tap "APPROVE" | Wallet signature sent (mocked if no MWA) |
| View receipt | Tap "📤 Export" | JSON receipt printed to Alert |
| Check settlement | Wait 5s | Proof screen updates status |

---

## 10. Future Roadmap

### Day 30 (MVP + Polish)
- [ ] Add DePIN task schema to Action model
- [ ] Implement cooldown clock countdown
- [ ] Add Guardian yield display
- [ ] Support partial unstake UI

### Day 60 (Integration)
- [ ] Connect to live Helium DePIN tasks
- [ ] Reward reconciliation and reporting
- [ ] Permission-protected spending limits

### Day 90+ (Security)
- [ ] Kotlin Keystore module for local signing
- [ ] Hardware attestation verification
- [ ] Android-level receipt sealing

---

## 11. Career Positioning

**Strongest Statement**:
> "Built an Android app that binds readable transaction review to wallet authorization and produces cryptographically-verified receipts."

**Demonstrates**:
- Mobile app development (Expo/React Native)
- Blockchain integration (Solana, MWA, RPC)
- Applied cryptography (SHA-256 hashing, manifest canonicalization)
- Security design (review binding, evidence integrity)
- UX for high-stakes decisions (payment review UI)

**Hiring Profile**: Android System Engineer (Solana Mobile)
- Salary: $138k–$159k
- Requirements: Kotlin, HALs, TEE, applied crypto
- Clearance as proof: MWA integration, crypto hashing, secure file handling

---

## Appendices

### Appendix A: Dependencies

| Package | Purpose |
|---------|---------|
| `expo` | React Native framework |
| `@solana/web3.js` | RPC, transactions, key management |
| `@solana/spl-token` | Token program constants |
| `expo-crypto` | SHA-256 hashing |
| `expo-file-system` | File I/O |
| `expo-image-picker` | Camera access |
| `@react-native-async-storage/async-storage` | Persistence |
| `@react-navigation/bottom-tabs` | Tab navigation |

### Appendix B: Key Sources

- [Solana Web3.js Docs](https://docs.solana.com/de/developing/clients/javascript-reference)
- [Mobile Wallet Adapter](https://github.com/solana-mobile/mobile-wallet-adapter)
- [Expo Documentation](https://docs.expo.dev)
- [React Native Docs](https://reactnative.dev)

---

**Built for CLOCK IN Solana Mobile Hackathon 2026**  
**Clearance. See what you approve. Prove what happened.** 🔍
