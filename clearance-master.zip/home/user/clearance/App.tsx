import React, { useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StatusBar } from 'expo-status-bar';
import { PublicKey } from '@solana/web3.js';
import { HomeScreen } from './src/screens/HomeScreen';
import { ClearanceScreen } from './src/screens/ClearanceScreen';
import { ProofScreen } from './src/screens/ProofScreen';

const Tab = createBottomTabNavigator();

const DARK_BG = '#0a0a0a';
const DARK_CARD = '#1a1a1a';
const GREEN = '#00ff88';

export default function App() {
  const [wallet, setWallet] = useState<PublicKey | null>(null);

  // Simulate Mobile Wallet Adapter connection
  const handleConnect = () => {
    // In production, use @solana/mobile-wallet-adapter-web3js
    // For now, use a mock wallet address
    const mockKey = new PublicKey('So11111111111111111111111111111111111111112');
    setWallet(mockKey);
  };

  const handleDisconnect = () => {
    setWallet(null);
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={DARK_BG} />
      <NavigationContainer>
        <Tab.Navigator
          screenOptions={({ route }) => ({
            headerShown: false,
            tabBarActiveTintColor: GREEN,
            tabBarInactiveTintColor: '#666',
            tabBarStyle: {
              backgroundColor: DARK_CARD,
              borderTopWidth: 1,
              borderTopColor: GREEN,
              paddingBottom: 8,
              paddingTop: 8,
              height: 60,
            },
            tabBarLabelStyle: {
              fontSize: 11,
              fontWeight: 'bold',
              marginTop: 4,
            },
            tabBarIconStyle: {
              marginBottom: -4,
            },
          })}
        >
          <Tab.Screen
            name="Home"
            options={{
              tabBarLabel: 'Home',
              tabBarIcon: ({ color }) => <Text style={{ color, fontSize: 20 }}>🏠</Text>,
            }}
          >
            {() => (
              <HomeScreen
                wallet={wallet}
                onConnect={handleConnect}
                onDisconnect={handleDisconnect}
              />
            )}
          </Tab.Screen>

          <Tab.Screen
            name="Clearance"
            options={{
              tabBarLabel: 'Clear',
              tabBarIcon: ({ color }) => <Text style={{ color, fontSize: 20 }}>🔍</Text>,
            }}
          >
            {() => <ClearanceScreen wallet={wallet} />}
          </Tab.Screen>

          <Tab.Screen
            name="Proof"
            options={{
              tabBarLabel: 'Proof',
              tabBarIcon: ({ color }) => <Text style={{ color, fontSize: 20 }}>📜</Text>,
            }}
          >
            {() => <ProofScreen />}
          </Tab.Screen>
        </Tab.Navigator>
      </NavigationContainer>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: DARK_BG,
  },
});
